﻿using PromotionEngine.Management.Models;
using System.Collections.Generic;

namespace PromotionEngine.Management.Interface
{
    public interface IPromotionOfferService
    {
        int PromotionAOffer (int quantity, int pramotionASKUUnit, int pramotionAOfferValue, int pramotionAValue);
        int PromotionBOffer(int quantity, int pramotionASKUUnit, int pramotionAOfferValue, int pramotionAValue);
        int PromotionCDOffer(IEnumerable<Cart> cart);
    }
}
