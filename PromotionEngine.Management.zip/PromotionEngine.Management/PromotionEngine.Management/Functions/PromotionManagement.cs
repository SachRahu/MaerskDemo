using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using PromotionEngine.Interface;
using PromotionEngine.Management.Utils;
using Microsoft.Azure.Devices.Common.Extensions;
using Newtonsoft.Json;
using PromotionEngine.Management.Models;
using PromotionEngine.Management.Interface;

namespace PromotionEngine.Functions
{
    public class PromotionManagement
    {
        private readonly IPromotionService _promotionService;
        private readonly IPromotionOfferService _offerService;
        private string _requestMethod;
        private string _requestBody;
        private string _logTraceMessage;
        private readonly string _serviceName;

        public PromotionManagement(IPromotionService promotionService, IPromotionOfferService offerService)
        {
            _promotionService = promotionService;
            _serviceName = Settings.PramotionManagement;
            _offerService = offerService;
        }

        /// <summary>
        /// Promotion Engine API return GetSkus and return total product value after applying offer 
        /// </summary>
        /// <param name="request">request parameter</param>
        /// <param name="log"> log parameter</param>
        /// <returns>Return list of SKUs and Product Total</returns>
        [FunctionName("PromotionEngine")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = "Product/PromotionEngine")] HttpRequest request,
            ILogger log)
        {
            try
            {
                var clientId = request.Headers.GetValueOrDefault("ClientId");
                var correlationId = request.Headers.GetValueOrDefault("CorrelationId");
                _requestMethod = request.Method.ToUpper();
                _logTraceMessage = ApplicationUtils.LogMessage(_serviceName, _requestMethod, clientId, correlationId);
                if (request.Body != null)
                {
                    var streamReader = new StreamReader(request.Body);
                    _requestBody = await streamReader?.ReadToEndAsync();
                    streamReader.Close();
                }
                switch (_requestMethod)
                {
                    case "GET":
                        return await GetSkus();
                    case "POST":
                        return await CheckOutProduct(_requestBody);
                    default:
                        return ApplicationUtils.ReturnBadRequestObjectResult($"Unhandled request method provided {request.Method}");
                }              
            }            
            catch (TimeoutException ex)
            {
                log.LogError(ex, $"{_logTraceMessage} - Failed for TimeoutException with status  {StatusCodes.Status408RequestTimeout}. TimeoutException: {ex.Message}");
                return ApplicationUtils.ReturnFailureResult(StatusCodes.Status408RequestTimeout);
            }
            catch (ArgumentException ex)
            {
                log.LogError(ex, $"{_logTraceMessage} - Failed for ArgumentException with status {StatusCodes.Status400BadRequest}. ArgumentException: {ex.Message}");
                return ApplicationUtils.ReturnFailureResult(StatusCodes.Status400BadRequest);
            }
            catch (Exception ex)
            {
                log.LogError(ex, $"{_logTraceMessage} - Failed with status {StatusCodes.Status500InternalServerError}. Exception: {ex.Message}");
                return ApplicationUtils.ReturnFailureResult(StatusCodes.Status500InternalServerError);
            }
        }

        /// <summary>
        /// Check out product function apply offer and return total value
        /// </summary>
        /// <param name="requestBody">requestBodyparam>
        /// <returns> return total value</returns>
        private async Task<IActionResult> CheckOutProduct(string requestBody)
        {
            var carts = JsonConvert.DeserializeObject<List<Cart>>(requestBody);
            var result = _promotionService.CheckOut(carts, _offerService);           
            return new OkObjectResult(result);
        }

        /// <summary>
        /// Get list of SKUs
        /// </summary>
        /// <returns>return list of skus</returns>
        private async Task<IActionResult> GetSkus()
        {
            var items = _promotionService.GetSkus();

            if (items.Count == 0)
            {
                return ApplicationUtils.ReturnNotFoundObjectResult($"SKUs not found.");
            }

            return new OkObjectResult(items);
        }
    }
}
