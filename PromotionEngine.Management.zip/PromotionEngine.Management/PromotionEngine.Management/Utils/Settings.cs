﻿
namespace PromotionEngine.Management.Utils
{
    public class Settings
    {
        public const string ErrorMessage = "Failed to perform operation. Please try again and contact support team if problem remain persists.";
        public const string PramotionManagement = "Pramotion Management Service";
        public const int PramotionAOfferValue = 130;
        public const int PramotionAValue = 50;
        public const int PramotionASKUUnit = 3;
        public const int PramotionBOfferValue = 45;
        public const int PramotionBValue = 30;
        public const int PramotionBSKUUnit = 2;
        public const int PramotionCValue = 20;
        public const int PramotionCSKUUnit = 1;
        public const int PramotionDValue = 15;
        public const int PramotionDSKUUnit = 1;
        public const int PramotionCDOfferValue = 30;
   

    }
}
