﻿using Microsoft.AspNetCore.Mvc;
using PromotionEngine.Management.Models;

namespace PromotionEngine.Management.Utils
{
    public static class ApplicationUtils
    {
        public static IActionResult ReturnNotFoundObjectResult(string message)
        {
            return new NotFoundObjectResult(new RequestError
            {
                Error = NotFound.Title,
                Message = message,
                ResponseCode = NotFound.Code
            });
        }

        public static IActionResult ReturnBadRequestObjectResult(string message)
        {
            return new BadRequestObjectResult(new RequestError
            {
                Error = BadRequest.Title,
                Message = message,
                ResponseCode = BadRequest.Code
            });
        }

        public static IActionResult ReturnFailureResult(int statusCodes, string message = Settings.ErrorMessage)
        {
            var responseError = new RequestError
            {
                Error = "Operation failure",
                Message = message,
                ResponseCode = statusCodes
            };
            return new ObjectResult(responseError)
            {
                StatusCode = statusCodes
            };
        }

        public static string LogMessage(string serviceName, string requestMethod, string clientId, string correlationId)
        {
            return $"{serviceName} {requestMethod} with Client Id: {clientId} and Correlation ID: {correlationId}";
        }

    }
}
